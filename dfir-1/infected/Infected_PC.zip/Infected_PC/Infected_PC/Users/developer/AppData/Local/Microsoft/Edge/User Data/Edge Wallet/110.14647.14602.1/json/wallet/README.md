# Discription
Please keep in sync with "src\ux\Microsoft.Pay.Web\wwwroot\json\wallet\"